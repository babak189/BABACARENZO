package com.moteur;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Enemy {

    private Texture texture;
    private float x;
    private float y;
    private boolean alive = true;

    private float width = 48f;
    private float height = 48f;

    private boolean deadly = false;

    private float vx = -60f;
    private float vy = 0f;

    private float screenW = 1280f;
    private float screenH = 720f;

    public Enemy(Texture texture, float startX, float startY) {
        this.texture = texture;
        this.x = startX;
        this.y = startY;
    }

    public void setScreenSize(float w, float h) {
        this.screenW = w;
        this.screenH = h;
    }

    public void updatePatrol(float delta) {
        if (!alive) return;
        x += vx * delta;

        if (x < 0) {
            x = 0;
            vx = Math.abs(vx);
        }
        if (x + width > screenW) {
            x = screenW - width;
            vx = -Math.abs(vx);
        }
    }

    public void updateChase(float px, float py, float speed, float delta) {
        if (!alive) return;

        float cx = x + width / 2f;
        float cy = y + height / 2f;
        float dx = px - cx;
        float dy = py - cy;

        float dist2 = dx * dx + dy * dy;
        if (dist2 == 0) return;

        float len = (float) Math.sqrt(dist2);
        x += (dx / len) * speed * delta;
        y += (dy / len) * speed * delta;

        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x + width > screenW) x = screenW - width;
        if (y + height > screenH) y = screenH - height;
    }

    public void render(SpriteBatch batch) {
        if (!alive) return;
        batch.draw(texture, x, y, width, height);
    }

    public boolean isAlive() {
        return alive;
    }

    public void kill() {
        alive = false;
    }

    public float getX() { return x; }
    public float getY() { return y; }

    public boolean touches(float px, float py, float pw, float ph) {
        if (!alive) return false;
        return x < px + pw &&
               x + width > px &&
               y < py + ph &&
               y + height > py;
    }

    public boolean isDeadly() {
        return deadly;
    }

    public void setDeadly(boolean deadly) {
        this.deadly = deadly;
    }

    public float getWidth() { return width; }
    public float getHeight() { return height; }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float getCenterX() { return x + width / 2f; }
    public float getCenterY() { return y + height / 2f; }
}