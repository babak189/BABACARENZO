package com.moteur;

import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;

import com.badlogic.gdx.math.Rectangle;
import java.util.ArrayList;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;


import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.audio.Sound;

public class GameMain extends ApplicationAdapter {

    private SpriteBatch batch;

    private Texture mapTexture;
    private Texture playerTexture;
    private Texture enemyTexture;
    private Texture brigitteTexture;

    private OrthographicCamera camera;
    private Viewport viewport;
    private OrthographicCamera uiCamera;

    private static final float WORLD_WIDTH = 1536f;
    private static final float WORLD_HEIGHT = 1024f;


    private Sound loseSound;
    private Sound winSound;

    private Player player;
    private TiledMap tiledMap;
    private ArrayList<Rectangle> collisionRectangles;


    private BitmapFont font;

    private SpriteBatch uiBatch;



    private int score = 0;
    private int lives = 3;
    private boolean victory = false;
    private boolean gameOver = false;

    private int wave = 1;
    private static final int MAX_WAVE = 3;

    public static final float SPRITE_SCALE = 2f;


    private float playerSpawnX;
    private float playerSpawnY;

    private static final int ENEMY_COUNT = 4;
    private float[] enemyX = new float[ENEMY_COUNT];
    private float[] enemyY = new float[ENEMY_COUNT];
    private boolean[] enemyAlive = new boolean[ENEMY_COUNT];
    private int[] enemyDirX = new int[ENEMY_COUNT];
    private int[] enemyDirY = new int[ENEMY_COUNT];

    private float enemySpeed = 75f;
    private float chaseSpeed = 60f;

    private float brigitteX;
    private float brigitteY;
    private float brigitteVY;
    private float brigitteMinY;
    private float brigitteMaxY;

    @Override
    public void create() {
        batch = new SpriteBatch();
        uiBatch = new SpriteBatch();
        font = new BitmapFont();
        uiCamera = new OrthographicCamera();
        uiCamera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        uiCamera.update();


        mapTexture = new Texture("map.png");
        playerTexture = new Texture("player.png");
        enemyTexture = new Texture("enemy.png");
        brigitteTexture = new Texture("brigitte.png");

        camera = new OrthographicCamera();
        viewport = new StretchViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
        viewport.apply();

        camera.position.set(WORLD_WIDTH / 2f, WORLD_HEIGHT / 2f, 0);
        camera.update();


        loseSound = null;
        winSound = null;


        tiledMap = new TmxMapLoader().load("map.tmx");
        collisionRectangles = new ArrayList<>();

        MapObjects objects = tiledMap.getLayers().get("Collisions").getObjects();

        int mapHeightPixels = mapTexture.getHeight();

        for (MapObject obj : objects) {
            if (obj instanceof RectangleMapObject) {
                Rectangle rect = ((RectangleMapObject) obj).getRectangle();
                rect.y = mapHeightPixels - rect.y - rect.height;
                collisionRectangles.add(rect);
            }
        }

        System.out.println("Nombre de collisions : " + collisionRectangles.size());

        startWave(1);

    }

    private void startWave(int waveNumber) {
        this.wave = waveNumber;

        float factor = 1f + 0.15f * (waveNumber - 1);
        enemySpeed = 60f * factor;
        chaseSpeed = enemySpeed;

        playerSpawnX = 60f;
        playerSpawnY = WORLD_HEIGHT / 2f - 32f;


        player = new Player(playerTexture, playerSpawnX, playerSpawnY);
        player.setCollisionRectangles(collisionRectangles);

        for (int i = 0; i < ENEMY_COUNT; i++) {
            enemyAlive[i] = true;
            enemyX[i] = WORLD_WIDTH - 140f - (i * 70f);
            enemyY[i] = WORLD_HEIGHT / 2f + (i - 2) * 90f;

        }
        for (int i = 0; i < ENEMY_COUNT; i++) {
            enemyDirX[i] = Math.random() < 0.5 ? 1 : -1;
            enemyDirY[i] = Math.random() < 0.5 ? 1 : -1;
        }

        brigitteX = WORLD_WIDTH - 90f;
        brigitteY = WORLD_HEIGHT / 2f - 32f;
        brigitteMaxY = WORLD_HEIGHT - 40f - 64f;

        brigitteMinY = 40f;
        brigitteVY = 80f * factor;

        victory = false;
        gameOver = false;
    }

    @Override
    public void render() {
        float delta = Gdx.graphics.getDeltaTime();

        if ((victory || gameOver) && Gdx.input.justTouched()) {
            score = 0;
            lives = 3;
            victory = false;
            gameOver = false;
            startWave(1);
        }


        if (!victory && !gameOver) {
            player.update(delta);
            updateEnemies(delta);
            updateBrigitte(delta);
            checkCollisions();
        }


        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.update();
        batch.setProjectionMatrix(camera.combined);

        batch.begin();

        batch.draw(mapTexture, 0, 0);


        for (int i = 0; i < ENEMY_COUNT; i++) {
            if (enemyAlive[i]) {
                batch.draw(
                    enemyTexture,
                    enemyX[i],
                    enemyY[i],
                    64 * SPRITE_SCALE,
                    64 * SPRITE_SCALE
                );
                font.draw(batch, "Lv " + (wave + i), enemyX[i], enemyY[i] + 76);
            }
        }

        batch.draw(
            brigitteTexture,
            brigitteX,
            brigitteY,
            64 * SPRITE_SCALE,
            64 * SPRITE_SCALE
        );


        player.render(batch);

        

        batch.end();

        uiBatch.setProjectionMatrix(uiCamera.combined);
        uiBatch.begin();

        font.draw(uiBatch, "Score : " + score, 10, Gdx.graphics.getHeight() - 10);
        font.draw(uiBatch, "Vies : " + lives, 10, Gdx.graphics.getHeight() - 30);
        font.draw(uiBatch, "Vague : " + wave,
            Gdx.graphics.getWidth() - 140,
            Gdx.graphics.getHeight() - 10);

        if (gameOver) {
            font.draw(uiBatch, "GAME OVER",
                Gdx.graphics.getWidth() / 2f - 50,
                Gdx.graphics.getHeight() / 2f + 40);
            font.draw(uiBatch, "Clique pour recommencer",
                Gdx.graphics.getWidth() / 2f - 100,
                Gdx.graphics.getHeight() / 2f);
        } else if (victory) {
            font.draw(uiBatch, "VICTOIRE !",
                Gdx.graphics.getWidth() / 2f - 50,
                Gdx.graphics.getHeight() / 2f + 40);
            font.draw(uiBatch, "Clique pour recommencer",
                Gdx.graphics.getWidth() / 2f - 100,
                Gdx.graphics.getHeight() / 2f);
        }

        uiBatch.end();

    }

    private void updateEnemies(float delta) {
        float playerCenterX = player.getX() + player.getWidth() / 2f;
        float playerCenterY = player.getY() + player.getHeight() / 2f;

        float baseSpeed = enemySpeed + 10f * (wave - 1);
        float currentChaseSpeed = baseSpeed*1.4f;
        float chaseRadius = 360f + 30f * (wave - 1);
        float chaseRadius2 = chaseRadius * chaseRadius;

        for (int i = 0; i < ENEMY_COUNT; i++) {
            if (!enemyAlive[i]) continue;

            float enemyCenterX = enemyX[i] + 32f;
            float enemyCenterY = enemyY[i] + 32f;

            float dx = playerCenterX - enemyCenterX;
            float dy = playerCenterY - enemyCenterY;
            float dist2 = dx * dx + dy * dy;

            if (dist2 < chaseRadius2) {
                float dist = (float) Math.sqrt(dist2);
                if (dist > 0.001f) {
                    float vx = dx / dist;
                    float vy = dy / dist;
                    enemyX[i] += vx * currentChaseSpeed * delta;
                    enemyY[i] += vy * currentChaseSpeed * delta;
                }
            } else {
                enemyX[i] += enemyDirX[i] * baseSpeed * delta;
                enemyY[i] += enemyDirY[i] * baseSpeed * delta;

                if (Math.random() < 0.005) {
                    enemyDirX[i] *= -1;
                }
                if (Math.random() < 0.005) {
                    enemyDirY[i] *= -1;
                }
            }


            if (enemyX[i] < 0) {
                enemyX[i] = 0;
                enemyDirX[i] = 1;
            } else if (enemyX[i] + 64 > WORLD_WIDTH) {
                enemyX[i] = WORLD_WIDTH - 64;
                enemyDirX[i] = -1;
            }


            if (enemyY[i] < 0) {
                enemyY[i] = 0;
                enemyDirY[i] = 1;
            } else if (enemyY[i] + 64 > WORLD_HEIGHT) {
                enemyY[i] = WORLD_HEIGHT - 64;
                enemyDirY[i] = -1;
            }

        }
    }

    private void updateBrigitte(float delta) {
        brigitteY += brigitteVY * delta;
        if (brigitteY < brigitteMinY) {
            brigitteY = brigitteMinY;
            brigitteVY = -brigitteVY;
        }
        if (brigitteY > brigitteMaxY) {
            brigitteY = brigitteMaxY;
            brigitteVY = -brigitteVY;
        }
    }

    private void checkCollisions() {
    float px = player.getX();
    float py = player.getY();
    float pw = player.getWidth();
    float ph = player.getHeight();

    for (int i = 0; i < ENEMY_COUNT; i++) {
        if (!enemyAlive[i]) continue;

        if (overlaps(px, py, pw, ph, enemyX[i], enemyY[i], 64f, 64f)) {

            if (loseSound != null) {
                loseSound.play();
            }

            lives--;

            if (lives <= 0) {
                gameOver = true;
                return;
            }

            
            player = new Player(playerTexture, playerSpawnX, playerSpawnY);
            player.setCollisionRectangles(collisionRectangles);
            return;
        }
    }

    
    if (overlaps(px, py, pw, ph, brigitteX, brigitteY, 64f, 64f)) {

        if (wave < MAX_WAVE) {
            score += 10;
            startWave(wave + 1);
            return;
        } else {
            victory = true;
            if (winSound != null) {
                winSound.play();
            }
            return;
        }
    }


    }

    private boolean overlaps(float x1, float y1, float w1, float h1,
                             float x2, float y2, float w2, float h2) {
        return x1 < x2 + w2 &&
                x1 + w1 > x2 &&
                y1 < y2 + h2 &&
                y1 + h1 > y2;
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        uiCamera.setToOrtho(false, width, height);
        uiCamera.update();
    }


    @Override
    public void dispose() {
        uiBatch.dispose();
        batch.dispose();
        font.dispose();
        mapTexture.dispose();
        playerTexture.dispose();
        enemyTexture.dispose();
        brigitteTexture.dispose();
        if (loseSound != null) {
            loseSound.dispose();
        }
        if (winSound != null) {
            winSound.dispose();
        }
    }
}
