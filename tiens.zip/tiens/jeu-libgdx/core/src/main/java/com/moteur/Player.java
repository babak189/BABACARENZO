package com.moteur;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.ArrayList;
import com.badlogic.gdx.math.Rectangle;


public class Player {

    private ArrayList<Rectangle> collisionRectangles;
    private Texture texture;
    private float x;
    private float y;

    private float width = 64f;
    private float height = 64f;

    private float speed = 220f;

    public Player(Texture texture, float x, float y) {
        this.texture = texture;
        this.x = x;
        this.y = y;
    }

    public void update(float delta) {
        float dx = 0;
        float dy = 0;

        if (Gdx.input.isKeyPressed(Input.Keys.Z)
                || Gdx.input.isKeyPressed(Input.Keys.W)
                || Gdx.input.isKeyPressed(Input.Keys.UP)) {
            dy += speed * delta;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.S)
                || Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            dy -= speed * delta;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.Q)
                || Gdx.input.isKeyPressed(Input.Keys.A)
                || Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            dx -= speed * delta;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.D)
                || Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            dx += speed * delta;
        }

        float nextX = x + dx;
        float nextY = y + dy;

        Rectangle nextPosition = new Rectangle(nextX, nextY, width, height);

        boolean collision = false;

        if (collisionRectangles != null) {
            for (Rectangle rect : collisionRectangles) {
                if (rect.overlaps(nextPosition)) {
                    collision = true;
                    break;
                }
            }
        }

        if (!collision) {
            x = nextX;
            y = nextY;
        }
    }

    public void setCollisionRectangles(ArrayList<Rectangle> rects) {
        this.collisionRectangles = rects;
    }


    public void render(SpriteBatch batch) {
        batch.draw(
            texture,
            x,
            y,
            width * GameMain.SPRITE_SCALE,
            height * GameMain.SPRITE_SCALE
        );
}


    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public void resetPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }
}